"use strict";

const doubleIt = num => num * 2;

const init = () => {
  // hook up UI
  const output = document.querySelector("#output");
  const numberField = document.querySelector("#number");
  const btnDouble = document.querySelector("#btn-double");

  btnDouble.onclick = () => {
    // the .value of an <input> element are always of type `String`
    // so we need to convert it to a `Number`
    const num = Number(numberField.value.trim()) || 0;
    const doubledNum = doubleIt(num);
    output.innerHTML = `${num} doubled is ${doubledNum}`;
  };
};

window.onload = init;


/*
Instructions:
- Let's convert this over to ES6 module syntax
- Don't forget that modules need to run off of a web server

1) Change the 

*/
